package com.ntl.srs.util;

import java.sql.Connection;

public interface DBUtil {

	static Connection getDBConnection(String driverType)
	{
		Connection conn=null;
		return conn;
		
	}
	
}
