package flight.com.ntl.FRS;

/**
 * Hello world!
 *
 */
public class Flight 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
